<?php



$PHPMAILER_LANG['buggy_php']            = 'Your PHP version is affected by a bug that may result in corrupted messages. To fix this, use SMTP for sending, disable the mail.add_x_header option in your php.ini, switch to MacOS or Linux, or upgrade your PHP version to 7.0.17+ or 7.1.3+.';
$PHPMAILER_LANG['connect_host']         = 'SMTP Error: Could not connect to SMTP server.';
$PHPMAILER_LANG['data_not_accepted']    = 'SMTP Error: Data not accepted.';
$PHPMAILER_LANG['empty_message']        = 'Message body empty.';
$PHPMAILER_LANG['encoding']             = 'Unknown encoding: ';
$PHPMAILER_LANG['execute']              = 'Could not execute command: ';
$PHPMAILER_LANG['extension_missing']    = 'Missing extension: ';
$PHPMAILER_LANG['file_access']          = 'Could not access file: ';
$PHPMAILER_LANG['file_open']            = 'File Error: Could not open file: ';
$PHPMAILER_LANG['from_failed']          = 'The following From address failed: ';
$PHPMAILER_LANG['instantiate']          = 'Could not instantiate mail function.';
$PHPMAILER_LANG['invalid_address']      = 'Invalid address: ';
$PHPMAILER_LANG['invalid_header']       = 'Invalid header name or value';
$PHPMAILER_LANG['invalid_hostentry']    = 'Invalid hostentry: ';
$PHPMAILER_LANG['invalid_host']         = 'Invalid host: ';
$PHPMAILER_LANG['mailer_not_supported'] = ' mailer is not supported.';
$PHPMAILER_LANG['provide_address']      = 'You must provide at least one recipient email address.';
$PHPMAILER_LANG['recipients_failed']    = 'SMTP Error: The following recipients failed: ';
$PHPMAILER_LANG['signing']              = 'Signing Error: ';
$PHPMAILER_LANG['smtp_code']            = 'SMTP code: ';
$PHPMAILER_LANG['smtp_code_ex']         = 'Additional SMTP info: ';
$PHPMAILER_LANG['smtp_connect_failed']  = 'SMTP connect() failed.';
$PHPMAILER_LANG['smtp_detail']          = 'Detail: ';
$PHPMAILER_LANG['smtp_error']           = 'SMTP server error: ';
$PHPMAILER_LANG['variable_set']         = 'Cannot set or reset variable: ';

?>
