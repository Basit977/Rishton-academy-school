<?php include('shared/_header.php');?>
<style>
    .justify-text {
        text-align: justify;
    }
</style>
<body>
    <main>
        <div class="big-wrapper light">
            <img src="./images/shape.png" alt="" class="shape" />

            
     <?php include('shared/_navbar.php'); ?>



            <div class="container mt-5">


    
                <div class="card border-0 shadow about-card">
                    <div class="card-body mt-5 mb-2 mx-3 ">
                        <h3 class="card-title">
                        <span class="text-primary icon-hover"><i class="fa-solid fa-paperclip"></i></span>    
                        About us</h3>
                        <p class="card-text fs-5 text-justify justify-text my-20">
                        Welcome to Rishton Academy Primary School, a vibrant and nurturing educational community committed to fostering a love for learning in every child. As a forward-thinking institution, we pride ourselves on our dedication to academic excellence and the holistic development of our students. Our passionate team of educators and staff work tirelessly to create a supportive and inclusive environment where each student can thrive both academically and personally.

                        In our ongoing efforts to enhance the educational experience, we have transitioned from traditional paper-based records to a modern, web-based digital system. This new system allows us to efficiently manage and access vital information about our pupils, parents, teachers, and classes. By embracing technology, we aim to improve communication, streamline administrative tasks, and ensure that we can focus more on what truly matters – the growth and success of our students.

                        At Rishton Academy Primary School, we believe in the potential of every child and are dedicated to providing the highest quality education to help them achieve their dreams. Thank you for being a part of our community. We look forward to working together to create a bright future for all our students.
                        </p>
                    </div>
                    <div class="mb-4" style="width: 100%;  display: flex; align-items: center; justify-content: center;">
                    <img style="width: 400px;"  src="./images/fav.png" class="card-img-bottom" alt="...">
                    </div>
                </div>


                
            </div>








        </div>


    </main>




  
    <?php include('shared/_footer.php'); ?>